# fashion-mnist-end-to-end-project
This repository is about build a Fashion MNIST classifier with a Streamlit interface and deploying it as a docker container

Refer YouTube video for step-by-step guide and explanation: https://youtu.be/sb2tm3pu17k
